var labelsxml = new Array();
var forecastxml = new Array();
var salesxml = new Array();
var labelsjson = new Array();
var radiusjson = new Array();
var pieData = new Array();
var colors = new Array("red", "teal", "orange", "blue", "purple", "yellow", "green", "aqua");


	// load up values from XML
		$(document).on("pagecreate", "#charts", function() {
			console.log("in #charts");
			$.ajax({
				type: "GET",
				url: "chart.xml",
				dataType: "xml",
				success:loadChartData
			});
			
		});


		function loadChartData(xml)
		{
			xx = 0;
			$("#linehead").html($(xml).find("title").text());
			$("#linelegend").html("<div style='background:rgba(220,0,0,0.5);'>Forecast</div>");
			$("#linelegend").append("<div style='background:rgba(0,220,0,0.5);'>Sales</div>");
			
			// load up forecast and sales arrays
			
		}	

		
// Line Chart		
$(document).on("pageshow", "#line", function() {
	
});
//------------------ end of line ------------------

// Bar chart from XML file
$(document).on("pageshow", "#barxml", function() {

			
			$("#legend").html("<p style='background:red;color:white;'>Forecast</p>" + 
												"<p style='background:blue;color:white;'>Sales</p>");
});
//------------------ end of bar / xml ------------------

// Bar chart from JSON file
$(document).on("pageshow", "#barjson", function() {
	$.getJSON("planets_ints.json", function(data) {
		// load up planet radius array

		
		// draw chart
		
	});
});
//------------------ end of bar / json ------------------

// Pie chart from JSON file
$(document).on("pageshow", "#pie", function() {
	$.getJSON("planets_ints.json", function(data) {
		// load radius array
		
		
		// draw chart
	

		// chart legend
			$("#pieLegend").html(
				"<table>" + 
					"<tr><td>" + labelsjson[0] + "</td>" + "<td style='background:" + colors[0] + ";'>" + pieData[0] + "</td></tr>" +
					"<tr><td>" + labelsjson[1] + "</td>" + "<td style='background:" + colors[1] + ";'>" + pieData[1] + "</td></tr>" +
					"<tr><td>" + labelsjson[2] + "</td>" + "<td style='background:" + colors[2] + ";'>" + pieData[2] + "</td></tr>" +
					"<tr><td>" + labelsjson[3] + "</td>" + "<td style='background:" + colors[3] + ";'>" + pieData[3] + "</td></tr>" +
					"<tr><td>" + labelsjson[4] + "</td>" + "<td style='background:" + colors[4] + ";'>" + pieData[4] + "</td></tr>" +
					"<tr><td>" + labelsjson[5] + "</td>" + "<td style='background:" + colors[5] + ";'>" + pieData[5] + "</td></tr>" +
					"<tr><td>" + labelsjson[6] + "</td>" + "<td style='background:" + colors[6] + ";'>" + pieData[6] + "</td></tr>" +
					"<tr><td>" + labelsjson[7] + "</td>" + "<td style='background:" + colors[7] + ";'>" + pieData[7] + "</td></tr>" +
				"</table>");	
				
/* 
		// Earth to Mercury and Venus
		var pieChart = [
			{label : labelsjson[0],value : pieData[0],color : colors[0]},
			{label : labelsjson[1],value : pieData[1],color : colors[1]},
			{label : labelsjson[2],value : pieData[2],color : colors[2]} ]		

			cvs = document.getElementById("pieCanvas1").getContext('2d');
			myChart = new Chart(cvs).Pie(pieChart);	

			$("#pieLegend1").html(
				"<table><tr><td>" + labelsjson[0] + "</td>" +
							 "<td style='background:" + colors[0] + ";'>" + 
										pieData[0] + "</td></tr>" +
							"<tr><td>" + labelsjson[1] + "</td>" +
							 "<td style='background:" + colors[1] + ";'>" + 
										pieData[1] + "</td></tr>" +
							"<tr><td>" + labelsjson[2] + "</td>" +
							 "<td style='background:" + colors[2] + ";'>" + 
										pieData[2] + "</td></tr>" +
				"</tr></table>");	

		// Earth to Mars, Jupiter and Saturn
		var pieChart = [
			{label : labelsjson[2],value : pieData[2],color : colors[2]},
			{label : labelsjson[3],value : pieData[3],color : colors[0]},
			{label : labelsjson[4],value : pieData[4],color : colors[1]},		
			{label : labelsjson[5],value : pieData[5],color : colors[3]} ]
			
			cvs = document.getElementById("pieCanvas2").getContext('2d');
			myChart = new Chart(cvs).Pie(pieChart);	

			$("#pieLegend2").html(
				"<table><tr><td>" + labelsjson[2] + "</td>" +
							 "<td style='background:" + colors[2] + ";'>" + 
										pieData[2] + "</td></tr>" +
							"<tr><td>" + labelsjson[3] + "</td>" +
							 "<td style='background:" + colors[0] + ";'>" + 
										pieData[3] + "</td></tr>" +
							"<tr><td>" + labelsjson[4] + "</td>" +
							 "<td style='background:" + colors[1] + ";'>" + 
										pieData[4] + "</td></tr>" +
							"<tr><td>" + labelsjson[5] + "</td>" +
							 "<td style='background:" + colors[3] + ";'>" + 
										pieData[5] + "</td></tr>" +			
				"</tr></table>");

		// Earth to Uranus and Neptune
		var pieChart = [
			{label : labelsjson[2],value : pieData[2],color : colors[2]},
			{label : labelsjson[6],value : pieData[6],color : colors[0]},
			{label : labelsjson[7],value : pieData[7],color : colors[1]} ]
			
			cvs = document.getElementById("pieCanvas3").getContext('2d');
			myChart = new Chart(cvs).Pie(pieChart);	

			$("#pieLegend3").html(
				"<table><tr><td>" + labelsjson[2] + "</td>" +
							 "<td style='background:" + colors[2] + ";'>" + 
										pieData[2] + "</td></tr>" +
							"<tr><td>" + labelsjson[6] + "</td>" +
							 "<td style='background:" + colors[0] + ";'>" + 
										pieData[6] + "</td></tr>" +
							"<tr><td>" + labelsjson[7] + "</td>" +
							 "<td style='background:" + colors[1] + ";'>" + 
										pieData[7] + "</td></tr>" +	
				"</tr></table>");			*/	
	});
});
//------------------ end of pie / json ------------------


